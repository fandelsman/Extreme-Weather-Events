# -*- coding: utf-8 -*-
"""
Created on Tue Apr 29 10:14:42 2025

@author: FedericoA
"""

import pandas as pd
import numpy as np
import statsmodels.api as sm
import statsmodels.formula.api as smf
from statsmodels.discrete.discrete_model import NegativeBinomial
import matplotlib.pyplot as plt

# Function to fit Quasi-Poisson Model
def fit_quasi_poisson(formula, data):
    model = smf.glm(
        formula=formula,
        data=data,
        family=sm.families.Poisson(link=sm.families.links.Log())
    ).fit(cov_type='HC0')  # Heteroskedasticity-robust covariance
    return model

# Function to fit Negative Binomial Model with estimated alpha
def fit_negative_binomial_with_alpha(formula, data):
    y, X = smf.ols(formula, data).endog, smf.ols(formula, data).exog
    nb_model = NegativeBinomial(y, X).fit(disp=0)
    return nb_model

# Function to test for overdispersion
def test_overdispersion(model, count_var, region, file):
    deviance = model.deviance
    df_resid = model.df_resid
    overdispersion_ratio = deviance / df_resid
    file.write(f'Overdispersion Test for {count_var} in {region}:\n')
    file.write(f'Residual Deviance: {deviance}\n')
    file.write(f'Degrees of Freedom: {df_resid}\n')
    file.write(f'Overdispersion Ratio: {overdispersion_ratio}\n')
    if overdispersion_ratio > 1:
        file.write("Overdispersion is present.\n")
    else:
        file.write("No significant overdispersion detected.\n")
    file.write("=" * 80 + "\n")

# List of count variables and regions
count_variables = ['Climatological', 'Hydrological', 'Meteorological', 'Total']
regions = ['NorthAmerica', 'Europe', 'SEA']

# Predictor variables
predictors = 'Global_Land_and_Ocean_Anomaly_C'

# Load the dataset
excel_file = r"C:\Users\FedericoA\OneDrive - ORTEC Finance\Thesis\PossibleData\Subselection\EMDAT_SummaryData2.xlsx"
df = pd.read_excel(excel_file)

# Rename columns to replace spaces with underscores
df.rename(columns=lambda x: x.replace(' ', '_'), inplace=True)

# Assuming your DataFrame is named df
# Step 1: Create combined event columns
df['Climatological_Total'] = (
    df['Climatological_NorthAmerica'] +
    df['Climatological_Europe'] +
    df['Climatological_SEA']
)

df['Hydrological_Total'] = (
    df['Hydrological_NorthAmerica'] +
    df['Hydrological_Europe'] +
    df['Hydrological_SEA']
)

df['Meteorological_Total'] = (
    df['Meteorological_NorthAmerica'] +
    df['Meteorological_Europe'] +
    df['Meteorological_SEA']
)

# Step 2: Plot
plt.figure(figsize=(12, 6))

plt.bar(df['Year'], df['Climatological_Total'], bottom=df['Meteorological_Total'] + df['Hydrological_Total'], color='orange', label='Climatological')
plt.bar(df['Year'], df['Hydrological_Total'], bottom=df['Meteorological_Total'], color='blue', label='Hydrological')
plt.bar(df['Year'], df['Meteorological_Total'],
        color='limegreen', label='Meteorological')

# Step 3: Customize
plt.xlabel('Year')
plt.ylabel('Number of Extreme Weather Events')
plt.title('Total of Extreme Weather Events in North America, Europe and Southeast Asia based on EM-DAT data')
plt.legend()
plt.tight_layout()
plt.show()

#%%

# File paths
output_file = r"C:\Users\FedericoA\OneDrive - ORTEC Finance\Thesis\PossibleData\OutputStatistical\Model_Results.txt"
summary_file = r"C:\Users\FedericoA\OneDrive - ORTEC Finance\Thesis\PossibleData\OutputStatistical\Model_Summary.csv"

# Create an empty list to store results for the CSV file
results_summary = []

# Open the text file to save detailed results
with open(output_file, "w") as file:
    # Loop over each count variable and region
    for count_var in count_variables:
        for region in regions:
            formula = f'{count_var}_{region} ~ {predictors}'
            
            # Check if the required columns exist in the DataFrame
            required_columns = [f'{count_var}_{region}'] + predictors.split(' + ')
            if all(col in df.columns for col in required_columns):
                
                # Fit Quasi-Poisson Model
                quasi_poisson_model = fit_quasi_poisson(formula, df)
                
                # Fit Negative Binomial Model with estimated alpha
                negative_binomial_model = fit_negative_binomial_with_alpha(formula, df)
                
                # Retrieve and log alpha value for Negative Binomial
                alpha = negative_binomial_model.params[-1]  # Alpha is the last parameter
                alpha_bounds = np.exp(negative_binomial_model.conf_int()[-1])  # Bounds for alpha
                file.write(f"Dispersion Parameter (alpha) for {count_var} in {region}: {alpha}\n")
                file.write(f"Alpha Lower Bound: {alpha_bounds[0]}, Alpha Upper Bound: {alpha_bounds[1]}\n")
                
                # Test for overdispersion in Quasi-Poisson Model
                test_overdispersion(quasi_poisson_model, count_var, region, file)
                
                # Write model summaries to the text file
                file.write(f"\nNegative Binomial Summary for {count_var} in {region}:\n")
                file.write(negative_binomial_model.summary().as_text() + "\n")
                file.write("=" * 80 + "\n")
                
                file.write(f"\nQuasi-Poisson Summary for {count_var} in {region}:\n")
                file.write(quasi_poisson_model.summary().as_text() + "\n")
                file.write("=" * 80 + "\n")
                
                # Extract coefficients and confidence intervals for Quasi-Poisson
                qp_coefficients = quasi_poisson_model.params
                qp_conf_int = quasi_poisson_model.conf_int(alpha=0.10)
                
                # Intercept: exponentiate coefficient and confidence interval
                qp_exp_intercept = np.exp(qp_coefficients['Intercept'])
                qp_bounds_intercept = np.exp(qp_conf_int.loc['Intercept'].values)
                
                # Predictor x1: keep coefficient and confidence interval as is (no exponentiation)
                qp_x1 = qp_coefficients['Global_Land_and_Ocean_Anomaly_C']
                qp_bounds_x1 = qp_conf_int.loc['Global_Land_and_Ocean_Anomaly_C'].values
                
                # Extract coefficients and confidence intervals for Negative Binomial
                nb_coefficients = negative_binomial_model.params
                nb_conf_int = negative_binomial_model.conf_int(alpha=0.10)
                
                # Intercept: exponentiate coefficient and confidence interval
                nb_exp_intercept = np.exp(nb_coefficients[0])  # Intercept
                nb_bounds_intercept = np.exp(nb_conf_int[0])
                
                # Predictor x1: keep coefficient and confidence interval as is (no exponentiation)
                nb_x1 = nb_coefficients[1]
                nb_bounds_x1 = nb_conf_int[1]
                
                # Append results for Quasi-Poisson
                results_summary.append({
                    "Count Variable": count_var,
                    "Region": region,
                    "Model": "Quasi-Poisson",
                    "Exp(Intercept)": qp_exp_intercept,
                    "Exp(Intercept)_LB": qp_bounds_intercept[0],
                    "Exp(Intercept)_UB": qp_bounds_intercept[1],
                    "x1": qp_x1,
                    "x1_LB": qp_bounds_x1[0],
                    "x1_UB": qp_bounds_x1[1],
                    "Alpha": "N/A",
                    "Alpha_LB": "N/A",
                    "Alpha_UB": "N/A"
                })
                
                # Append results for Negative Binomial
                results_summary.append({
                    "Count Variable": count_var,
                    "Region": region,
                    "Model": "Negative Binomial",
                    "Exp(Intercept)": nb_exp_intercept,
                    "Exp(Intercept)_LB": nb_bounds_intercept[0],
                    "Exp(Intercept)_UB": nb_bounds_intercept[1],
                    "x1": nb_x1,
                    "x1_LB": nb_bounds_x1[0],
                    "x1_UB": nb_bounds_x1[1],
                    "Alpha": alpha,
                    "Alpha_LB": alpha_bounds[0],
                    "Alpha_UB": alpha_bounds[1]
                })
            else:
                file.write(f"Skipping model for {count_var} in {region} due to missing columns.\n")

# Convert results to a DataFrame and save to CSV
summary_df = pd.DataFrame(results_summary)
summary_df.to_csv(summary_file, index=False)

# Display the summary DataFrame
print(summary_df)

#%%


#%%
import matplotlib.pyplot as plt
import numpy as np

# Loop over each count variable and region
for region in regions:
    for count_var in count_variables:
        col_name = f'{count_var}_{region}'
        
        # Check if the required column exists in the DataFrame
        if col_name in df.columns:
            # Observed Data
            observed_counts = df[col_name].dropna()  # Drop missing values
            
            # Sort the observed counts to group sequentially
            observed_counts = observed_counts.sort_values().reset_index(drop=True)
            
            # Calculate mean and variance in groups of 5 points
            group_size = 11
            num_groups = len(observed_counts) // group_size  # Number of full groups
            means = []
            variances = []
            
            for i in range(num_groups):
                group = observed_counts[i * group_size:(i + 1) * group_size]
                means.append(group.mean())
                variances.append(group.var())
            
            # Handle any remaining points (if total points are not divisible by group_size)
            remainder = len(observed_counts) % group_size
            if remainder > 0:
                group = observed_counts[-remainder:]
                means.append(group.mean())
                variances.append(group.var())
            
            # Plot Mean-Variance Relationship
            plt.figure(figsize=(8, 6))
            plt.scatter(means, variances, color='black', alpha=0.6, label='Observed Data')
            plt.title(f'Observed Mean vs Variance: {count_var} in {region}', fontsize=16)
            plt.xlabel('Mean', fontsize=14)
            plt.ylabel('Variance', fontsize=14)
            plt.legend(fontsize=12)
            plt.grid(True)
            
#%%
# Load the summary table from the CSV (generated earlier)
summary_file = r"C:\Users\FedericoA\OneDrive - ORTEC Finance\Thesis\PossibleData\OutputStatistical\Model_Summary.csv"
summary_df = pd.read_csv(summary_file)

# Temperature anomaly (e.g., FAR for 1°C warming)
x1 = 1.0  # Temperature anomaly in °C

# Function to calculate FAR given beta1 and temperature anomaly
def calculate_far(beta1, x1):
    return 1 - np.exp(-beta1 * x1)

# Add FAR calculations to the summary DataFrame
far_values = []
far_lb_values = []
far_ub_values = []

for _, row in summary_df.iterrows():
    if row["Model"] == "Quasi-Poisson" or row["Model"] == "Negative Binomial":
        # Extract beta1 (log coefficient of temperature anomaly) and its bounds
        beta1 = np.log(row["x1"])
        beta1_lb = np.log(row["x1_LB"])
        beta1_ub = np.log(row["x1_UB"])
        
        # Calculate FAR, FAR lower bound, and FAR upper bound
        far = calculate_far(beta1, x1)
        far_lb = calculate_far(beta1_lb, x1)
        far_ub = calculate_far(beta1_ub, x1)
        
        # Append values to the lists
        far_values.append(far)
        far_lb_values.append(far_lb)
        far_ub_values.append(far_ub)
    else:
        # If FAR is not applicable, append None
        far_values.append(None)
        far_lb_values.append(None)
        far_ub_values.append(None)

# Add FAR and bounds to the summary DataFrame
summary_df["FAR"] = far_values
summary_df["FAR_LB"] = far_lb_values
summary_df["FAR_UB"] = far_ub_values

# Save the updated summary table with FAR values and bounds
updated_summary_file = r"C:\Users\FedericoA\OneDrive - ORTEC Finance\Thesis\PossibleData\OutputStatistical\Model_Summary_with_FAR_and_Bounds.csv"
summary_df.to_csv(updated_summary_file, index=False)

# Display the updated summary DataFrame
print(summary_df)

#%%
from sklearn.metrics import mean_absolute_error, mean_squared_error

# Create an empty list to store diagnostics
diagnostics_summary = []

for count_var in count_variables:
    for region in regions:
        formula = f'{count_var}_{region} ~ {predictors}'
        
        # Check if the required columns exist in the DataFrame
        required_columns = [f'{count_var}_{region}'] + predictors.split(' + ')
        if all(col in df.columns for col in required_columns):
            
            # Fit models
            quasi_poisson_model = fit_quasi_poisson(formula, df)
            negative_binomial_model = fit_negative_binomial_with_alpha(formula, df)
            
            # Observed values
            observed = df[f'{count_var}_{region}']
            
            # Predicted values
            qp_predicted = quasi_poisson_model.predict()
            nb_predicted = negative_binomial_model.predict()
            
            # Calculate metrics
            diagnostics_summary.append({
                "Count Variable": count_var,
                "Region": region,
                "Model": "Quasi-Poisson",
                "MAE": mean_absolute_error(observed, qp_predicted),
                "MSE": mean_squared_error(observed, qp_predicted)
            })
            
            diagnostics_summary.append({
                "Count Variable": count_var,
                "Region": region,
                "Model": "Negative Binomial",
                "MAE": mean_absolute_error(observed, nb_predicted),
                "MSE": mean_squared_error(observed, nb_predicted)
            })

# Convert diagnostics to a DataFrame
diagnostics_df = pd.DataFrame(diagnostics_summary)

# Save the diagnostics table to a CSV file
diagnostics_file = r"C:\Users\FedericoA\OneDrive - ORTEC Finance\Thesis\PossibleData\OutputStatistical\Model_Diagnostics.csv"
diagnostics_df.to_csv(diagnostics_file, index=False)

# Display the diagnostics DataFrame
print(diagnostics_df)
#%%

# Function to plot residuals
def plot_residuals(model, observed, ax, title):
    predicted = model.predict()
    residuals = observed - predicted
    ax.scatter(predicted, residuals, alpha=0.6, edgecolor='k')
    ax.axhline(0, color='red', linestyle='--')
    ax.set_title(title)
    ax.set_xlabel('Predicted')
    ax.set_ylabel('Residuals')

# Function to plot observed vs. predicted
def plot_observed_vs_predicted(model, observed, ax, title):
    predicted = model.predict()
    ax.scatter(observed, predicted, alpha=0.6, edgecolor='k')
    ax.plot([min(observed), max(observed)], [min(observed), max(observed)], color='red', linestyle='--', label='Perfect Fit')
    ax.set_title(title)
    ax.set_xlabel('Observed')
    ax.set_ylabel('Predicted')
    ax.legend()

# Create subplots for residual plots
fig_residuals, axes_residuals = plt.subplots(len(count_variables), len(regions) * 2, figsize=(25, 15), constrained_layout=True)

# Create subplots for observed vs. predicted plots
fig_predictions, axes_predictions = plt.subplots(len(count_variables), len(regions) * 2, figsize=(25, 15), constrained_layout=True)

for i, count_var in enumerate(count_variables):
    for j, region in enumerate(regions):
        formula = f'{count_var}_{region} ~ {predictors}'
        quasi_resid_ax = axes_residuals[i, j * 2]       # Axes for Quasi-Poisson residuals
        nb_resid_ax = axes_residuals[i, j * 2 + 1]     # Axes for Negative Binomial residuals
        quasi_pred_ax = axes_predictions[i, j * 2]     # Axes for Quasi-Poisson observed vs. predicted
        nb_pred_ax = axes_predictions[i, j * 2 + 1]    # Axes for Negative Binomial observed vs. predicted
        
        if all(col in df.columns for col in [f'{count_var}_{region}'] + predictors.split(' + ')):
            # Fit models
            quasi_poisson_model = fit_quasi_poisson(formula, df)
            negative_binomial_model = fit_negative_binomial_with_alpha(formula, df)
            
            # Observed values
            observed = df[f'{count_var}_{region}']
            
            # Plot residuals for Quasi-Poisson
            plot_residuals(quasi_poisson_model, observed, quasi_resid_ax, f'{count_var} {region} (Quasi-Poisson Residuals)')
            
            # Plot residuals for Negative Binomial
            plot_residuals(negative_binomial_model, observed, nb_resid_ax, f'{count_var} {region} (Neg. Binomial Residuals)')
            
            # Plot observed vs. predicted for Quasi-Poisson
            plot_observed_vs_predicted(quasi_poisson_model, observed, quasi_pred_ax, f'{count_var} {region} (Quasi-Poisson Predicted)')
            
            # Plot observed vs. predicted for Negative Binomial
            plot_observed_vs_predicted(negative_binomial_model, observed, nb_pred_ax, f'{count_var} {region} (Neg. Binomial Predicted)')

# Add a title for the residuals figure
fig_residuals.suptitle('Comparison of Residuals: Quasi-Poisson vs Negative Binomial Models', fontsize=20)

# Add a title for the predictions figure
fig_predictions.suptitle('Comparison of Observed vs Predicted: Quasi-Poisson vs Negative Binomial Models', fontsize=20)

# Show the residuals figure
plt.figure(fig_residuals.number)
plt.show()

# Show the predictions figure
plt.figure(fig_predictions.number)
plt.show()
#%%
import numpy as np

# Function to calculate absolute and relative errors
def calculate_errors(observed, predicted):
    absolute_error = np.abs(observed - predicted)
    return absolute_error

# Loop over each count variable and region
for count_var in count_variables:
    for region in regions:
        formula = f'{count_var}_{region} ~ {predictors}'
        
        # Check if the required columns exist in the DataFrame
        required_columns = [f'{count_var}_{region}'] + predictors.split(' + ')
        if all(col in df.columns for col in required_columns):
            
            # Fit Quasi-Poisson Model
            quasi_poisson_model = fit_quasi_poisson(formula, df)
            
            # Fit Negative Binomial Model
            negative_binomial_model = fit_negative_binomial_with_alpha(formula, df)
            
            # Observed values
            observed = df[f'{count_var}_{region}']
            
            # Predicted values
            qp_predicted = quasi_poisson_model.predict()
            nb_predicted = negative_binomial_model.predict()
            
            # Calculate errors
            qp_abs_error = calculate_errors(observed, qp_predicted)
            nb_abs_error = calculate_errors(observed, nb_predicted)
            
            # Plot Absolute Errors vs Temperature Anomaly
            plt.figure(figsize=(10, 6))
            plt.scatter(df["Global_Land_and_Ocean_Anomaly_C"], qp_abs_error, alpha=0.6, label="Quasi-Poisson", color="blue")
            plt.scatter(df["Global_Land_and_Ocean_Anomaly_C"], nb_abs_error, alpha=0.6, label="Negative Binomial", color="orange")
            plt.axhline(0, color='red', linestyle='--', linewidth=1)
            plt.title(f"Absolute Errors vs Temperature Anomaly\n{count_var} - {region}")
            plt.xlabel("Temperature Anomaly (°C)")
            plt.ylabel("Absolute Error")
            plt.legend()
            plt.show()
            
#%%
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import patsy
from scipy.stats import pearsonr

# Dictionary to store the ratio qp(1.3) / qp(0.0) 
qp_prediction_ratios = {}

# Generate a range of temperature anomaly values
temperature_anomalies = np.linspace(-0.1, 1.5, 100)
index_0 = np.argmin(np.abs(temperature_anomalies - 0.0))
index_1_3 = np.argmin(np.abs(temperature_anomalies - 1.3))

# Define colors for each hazard type
hazard_colors = {
    'Climatological': 'orange',
    'Hydrological': 'blue',
    'Meteorological': 'green',
    'Total': 'red'
}

# Loop over each count variable and region
for count_var in count_variables:
    if "total" in count_var.lower():  # Exclude Total
        continue

    for region in regions:
        response_col = f'{count_var}_{region}'
        formula = f'{response_col} ~ {predictors}'

        # Check if required columns exist
        required_columns = [response_col] + predictors.split(' + ')
        if all(col in df.columns for col in required_columns):

            # Fit Quasi-Poisson Model
            quasi_poisson_model = fit_quasi_poisson(formula, df)

            # Generate predictions for a range of temperature anomalies
            qp_predictions = []
            for anomaly in temperature_anomalies:
                prediction_data = pd.DataFrame({predictors: [anomaly]})
                qp_predictions.append(quasi_poisson_model.predict(prediction_data)[0])

            # Save the ratio qp(1.3) / qp(0.0)
            key = (count_var, region)
            ratio = qp_predictions[index_1_3] / qp_predictions[index_0] if qp_predictions[index_0] != 0 else np.nan
            qp_prediction_ratios[key] = ratio

            # Plotting
            observed_counts = df[response_col]
            observed_anomalies = df[predictors]
            predicted_counts = quasi_poisson_model.predict()
            
            intercept = quasi_poisson_model.params['Intercept']
            n0 = np.exp(intercept)
            slope = quasi_poisson_model.params[predictors]
            
            # Proper exponential form of the equation
            eqn_label = fr"Quasi-Poisson: $N = {n0:.1f}*e^{{{slope:.1f}*Ta}}$"

            
            plt.figure(figsize=(10, 6))
            plt.plot(
                temperature_anomalies,
                qp_predictions,
                label=eqn_label,
                color=hazard_colors.get(count_var.split('_')[0].capitalize(), 'gray')
            )
            plt.scatter(
                observed_anomalies,
                observed_counts,
                label='Observed Counts',
                color='black',
                alpha=0.7
            )
            
            plt.title(f'Predicted and Observed Counts: {count_var} in {region}')
            plt.xlabel('Temperature Anomaly (°C)')
            plt.ylabel('Number of Events')
            plt.legend()
            plt.grid(True)
            plt.show()


# Convert to DataFrame if needed
qp_ratio_df = pd.DataFrame.from_dict(qp_prediction_ratios, orient='index', columns=['qp_ratio_1.3_to_0'])
qp_ratio_df.index = pd.MultiIndex.from_tuples(qp_ratio_df.index, names=['Hazard Type', 'Region'])

# Save to CSV
qp_ratio_df.to_csv('qp_prediction_ratios_1.3_over_0.csv')



#%% Only QuasiPoisson
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import statsmodels.api as sm
import patsy
import math

# Define function to fit a Quasi-Poisson model
def fit_quasi_poisson(formula, data):
    y, X = patsy.dmatrices(formula, data, return_type='dataframe')
    model = sm.GLM(y, X, family=sm.families.Poisson())
    results = model.fit(scale='X2')  # Quasi-Poisson with scaled deviance
    return results

# Define a function to assign colors
def get_color(event_type):
    if event_type.startswith("climatological"):
        return "orange"
    elif event_type.startswith("hydrological"):
        return "blue"
    elif event_type.startswith("meteorological"):
        return "green"
    else:
        return "gray"

# Store plot data
obs_pred_plots = []
residual_plots = []
titles = []
colors = []

# Loop over each count variable and region
for count_var in count_variables:
    # Skip if count_var indicates a 'Total' event type
    if "total" in count_var.lower():
        continue
   
    for region in regions:
        response_col = f'{count_var}_{region}'
        formula = f'{response_col} ~ {predictors}'

        # Check if required columns exist
        required_columns = [response_col] + predictors.split(' + ')
        if all(col in df.columns for col in required_columns):

            # Fit Quasi-Poisson model
            model = fit_quasi_poisson(formula, df)

            # Observed and predicted
            observed = df[response_col]
            predicted = model.predict()
            residuals = observed - predicted

            obs_pred_plots.append((predicted, observed))
            residual_plots.append((predicted, residuals))
            titles.append(f"{count_var} - {region}")
            colors.append(get_color(count_var))

# Determine subplot grid size
n_plots = len(obs_pred_plots)
cols = 3
rows = math.ceil(n_plots / cols)

# Plot: Observed vs Predicted
fig1, axes1 = plt.subplots(rows, cols, figsize=(cols * 5, rows * 4))
axes1 = axes1.flatten()

for i, (pred, obs) in enumerate(obs_pred_plots):
    axes1[i].scatter(pred, obs, alpha=0.6, color=colors[i])
    axes1[i].plot([obs.min(), obs.max()], [obs.min(), obs.max()], 'r--')
    axes1[i].set_title(f"{titles[i]}")
    axes1[i].set_xlabel("Predicted")
    axes1[i].set_ylabel("Observed")
    axes1[i].grid(True)

# Hide unused subplots
for ax in axes1[n_plots:]:
    ax.axis('off')

fig1.suptitle("Observed vs Predicted (Quasi-Poisson)", fontsize=24)
fig1.tight_layout(rect=[0, 0, 1, 0.96])
plt.show()

# Plot: Residuals vs Predicted
fig2, axes2 = plt.subplots(rows, cols, figsize=(cols * 5, rows * 4))
axes2 = axes2.flatten()

for i, (pred, resid) in enumerate(residual_plots):
    axes2[i].scatter(pred, resid, alpha=0.6, color=colors[i])
    axes2[i].axhline(0, color='red', linestyle='--')
    axes2[i].set_title(f"{titles[i]}")
    axes2[i].set_xlabel("Predicted")
    axes2[i].set_ylabel("Residuals")
    axes2[i].grid(True)

# Hide unused subplots
for ax in axes2[n_plots:]:
    ax.axis('off')

fig2.suptitle("Residuals vs Predicted (Quasi-Poisson)", fontsize=24)
fig2.tight_layout(rect=[0, 0, 1, 0.96])
plt.show()
            
#%%

count_variables = ['Climatological', 'Hydrological', 'Meteorological']

# Define colors for each hazard type
hazard_colors = {
    'Climatological': 'orange',
    'Hydrological': 'blue',
    'Meteorological': 'green',
    'Total': 'red'
}

# Temperature anomaly range (0 to 2°C)
temperature_anomalies = np.linspace(0, 2, 21)

# Loop over each region
for region in regions:
    plt.figure(figsize=(10, 6))
    for count_var in count_variables:
        formula = f'{count_var}_{region} ~ Global_Land_and_Ocean_Anomaly_C'
        
        # Check if the required columns exist in the DataFrame
        required_columns = [f'{count_var}_{region}', 'Global_Land_and_Ocean_Anomaly_C']
        if all(col in df.columns for col in required_columns):
            
            # Fit Quasi-Poisson Model
            quasi_poisson_model = fit_quasi_poisson(formula, df)
            
            # Extract beta1 and its confidence intervals
            beta1 = quasi_poisson_model.params['Global_Land_and_Ocean_Anomaly_C']
            beta1_bounds = quasi_poisson_model.conf_int(alpha=0.10).loc['Global_Land_and_Ocean_Anomaly_C'].values
            beta1_lb = beta1_bounds[0]
            beta1_ub = beta1_bounds[1]
            
            # Calculate FAR for each temperature anomaly
            far_values = 1 - np.exp(-beta1 * temperature_anomalies)
            far_lb_values = 1 - np.exp(-beta1_lb * temperature_anomalies)
            far_ub_values = 1 - np.exp(-beta1_ub * temperature_anomalies)
            
            # Plot FAR with bounds
            plt.plot(
                temperature_anomalies, 
                far_values, 
                label=f'{count_var}', 
                color=hazard_colors[count_var], 
                linewidth=2
            )
            plt.fill_between(
                temperature_anomalies, 
                far_lb_values, 
                far_ub_values, 
                color=hazard_colors[count_var], 
                alpha=0.2
            )
    
    # Customize plot
    plt.title(f'Fraction of Attributable Risk (FAR) in {region}', fontsize=16)
    plt.xlabel('Temperature Anomaly (°C)', fontsize=14)
    plt.ylabel('FAR', fontsize=14)
    plt.axhline(0, color='black', linewidth=0.8, linestyle='--')
    plt.axhline(1, color='black', linewidth=0.8, linestyle='--')
    plt.axvline(x=1.3, color='black', linestyle='--', linewidth=1.5, label='Ta(2024)')
    plt.legend(title='Hazard Type', fontsize=12)
    plt.ylim(0,1)
    plt.xlim(0,1.5)
    plt.grid(True)
    
#%%
# Temperature anomaly range (0 to 2°C)
temperature_anomalies = np.linspace(0, 2, 21)

# Data structure to store FAR results
far_results = []

# Loop over each region
for region in regions:
    for count_var in count_variables:
        formula = f'{count_var}_{region} ~ Global_Land_and_Ocean_Anomaly_C'
        
        # Check if the required columns exist in the DataFrame
        required_columns = [f'{count_var}_{region}', 'Global_Land_and_Ocean_Anomaly_C']
        if all(col in df.columns for col in required_columns):
            
            # Fit Quasi-Poisson Model
            quasi_poisson_model = fit_quasi_poisson(formula, df)
            
            # Extract beta1 and its confidence intervals
            beta1 = quasi_poisson_model.params['Global_Land_and_Ocean_Anomaly_C']
            beta1_bounds = quasi_poisson_model.conf_int().loc['Global_Land_and_Ocean_Anomaly_C'].values
            beta1_lb = beta1_bounds[0]
            beta1_ub = beta1_bounds[1]
            
            # Calculate FAR for each temperature anomaly
            for anomaly in temperature_anomalies:
                far = 1 - np.exp(-beta1 * anomaly)
                far_lb = 1 - np.exp(-beta1_lb * anomaly)
                far_ub = 1 - np.exp(-beta1_ub * anomaly)
                
                # Append results
                far_results.append({
                    "Region": region,
                    "Hazard Type": count_var,
                    "Temperature Anomaly (°C)": anomaly,
                    "FAR": far,
                    "FAR_LB": far_lb,
                    "FAR_UB": far_ub
                })

# Convert results to a DataFrame
far_df = pd.DataFrame(far_results)

# Save FAR results to CSV
output_csv = r"C:\Users\FedericoA\OneDrive - ORTEC Finance\Thesis\PossibleData\OutputStatistical\FAR_QuasiPoisson.csv"
far_df.to_csv(output_csv, index=False)

print(f"FAR results saved to {output_csv}")
