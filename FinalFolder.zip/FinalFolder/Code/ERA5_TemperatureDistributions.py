# -*- coding: utf-8 -*-
"""
Created on Fri Jul 18 14:01:07 2025

@author: FedericoA
"""

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

excel_file2 = r"C:\Users\FedericoA\OneDrive - ORTEC Finance\Thesis\PossibleData\Subselection\ERA5_Temperature.xlsx"
df3 = pd.read_excel(excel_file2)
df3 = df3.iloc[:, :2]
#%%

# Ensure that the 'date' column is in datetime format
df3['date'] = pd.to_datetime(df3['date'])

# Extract the year and month from the 'date' column
df3['year'] = df3['date'].dt.year
df3['month'] = df3['date'].dt.month

# Set up the plot style for seaborn
sns.set(style="whitegrid")

# List of years to plot
years_to_plot = [1950, 1975, 2000, 2024]

months = ["January", "February", "March", "April", "May", "June", "July", "August",
          "September", "October", "November", "December"]

# Create a 3x4 grid of subplots (3 rows, 4 columns for 12 months)
fig, axes = plt.subplots(3, 4, figsize=(16, 12), sharey=True)

# Loop through each month (1 to 12) and plot its distribution for the specified years
for month in range(1, 13):
    ax = axes[(month-1)//4, (month-1)%4]  # Determine row and column for each month
    for year in years_to_plot:
        monthly_data = df3[(df3['year'] == year) & (df3['month'] == month)]['2t']
        sns.kdeplot(monthly_data, label=str(year), ax=ax, shade=True, linewidth=1)

    # Customize the subplot
    ax.set_title(f'{months[month-1]}', fontsize=20)
    ax.set_xlabel('Temperature (C)',fontsize=16)
    ax.set_ylabel('Density',fontsize=16)
    ax.legend(title='Year', bbox_to_anchor=(1.05, 1), loc='upper left')

# Adjust the layout for better spacing and visibility
plt.tight_layout()
plt.show()