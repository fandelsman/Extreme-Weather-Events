# -*- coding: utf-8 -*-
"""
Created on Thu Apr  3 13:16:47 2025

@author: FedericoA
"""

import pandas as pd
import numpy as np
import geopandas as gpd
import matplotlib.pyplot as plt
import os

# Load the Excel file and specific sheet
file_path = r"C:\Users\FedericoA\OneDrive - ORTEC Finance\Thesis\PossibleData\Subselection\EMDAT_Europe.xlsx" 
sheet_name = "EWE Europe Country CarbonBrief"

df = pd.read_excel(file_path, sheet_name=sheet_name)
df = df.iloc[:-1] #remove grand total for events
df = df[~df['ISO'].isin(['MLT', 'LUX', 'LIE'])] #remove these 3 countries cause they dominate per km2 indices
# Load the Natural Earth dataset
world = gpd.read_file(r'C:\Users\FedericoA\Downloads\ne_10m_admin_0_countries/ne_10m_admin_0_countries.shp')

# Filter for European countries
europe = world[world['CONTINENT'] == 'Europe']


#%%
isos_in_df = set(df['ISO'].unique())
isos_in_europe = set(europe['ISO_A3_EH'].unique())

# Find unmatched codes
missing_in_europe = isos_in_df - isos_in_europe
print("ISO codes in df not found in europe:", missing_in_europe)
#%%

# Ensure your dataset has a column named 'iso_a3' that matches the ISO codes in the world dataset
merged = europe.merge(df, left_on='ISO_A3_EH', right_on='ISO')

# Define a function to plot the maps
def plot_density_map(data, column, title):
    fig, ax = plt.subplots(1, 1, figsize=(15, 10))
    data.boundary.plot(ax=ax)
    data.plot(column=column, ax=ax, legend=True,
              legend_kwds={'label': title,
                           'orientation': "horizontal"})
    ax.set_xlim(-30, 60)  # Set longitude limits
    ax.set_ylim(30, 75)  # Set latitude limits
    plt.title(title)
    plt.show()

# Plotting maps for each category
plot_density_map(merged, 'Climatological', 'Climatological Events (1970-2024)')
plot_density_map(merged, 'Hydrological', 'Hydrological Events (1970-2024)')
plot_density_map(merged, 'Meteorological', 'Meteorological Events (1970-2024)')
plot_density_map(merged, 'Grand Total', 'Grand Total Events (1970-2024)')
plot_density_map(merged, 'Climatological Events per km2 *1000', 'Climatological Events Index per Area (1970-2024)')
plot_density_map(merged, 'Hydrological Events per km2 *1000', 'Hydrological Events Index per Area (1970-2024)')
plot_density_map(merged, 'Meteorological Events per km2 *1000', 'Meteorological Events Index per Area (1970-2024)')
plot_density_map(merged, 'Events per km2 *1000', 'Total Events Index per Area (1970-2024)')
#%%
categories = [
    'Climatological Events per km2 *1000',
    'Hydrological Events per km2 *1000',
    'Meteorological Events per km2 *1000'
]

# Sort each column and grab top 10
rankings = {
    col: df[['ISO', 'Country Name', col]].sort_values(by=col, ascending=False).head(10)
    for col in categories
}

# Display each ranking
for col, table in rankings.items():
    print(f"\n📊 {col}")
    display(table)

#%%
import folium

os.chdir(r"C:\Users\FedericoA\OneDrive - ORTEC Finance\Thesis\PossibleData\Maps\Europe")

# Ensure CRS is correct and convert to GeoJSON
merged = merged.to_crs("EPSG:4326")
geo_json_data = merged.to_json()

# Define a mapping from category keywords to folium color scales
color_scales = {
    'climatological': 'Oranges',
    'hydrological': 'Blues',
    'meteorological': 'Greens',
    'total': 'Reds'
}

def get_color_scale(column_name):
    col_lower = column_name.lower()
    if 'climatological' in col_lower:
        return color_scales['climatological']
    elif 'hydrological' in col_lower:
        return color_scales['hydrological']
    elif 'meteorological' in col_lower:
        return color_scales['meteorological']
    elif 'total' in col_lower or 'grand total' in col_lower or 'events per km2' in col_lower:
        return color_scales['total']
    else:
        return 'YlGn'  # fallback color scale

# Generic function to create and save folium choropleth maps
def create_folium_map(geojson_data, data_df, column, title, filename):
    m = folium.Map(location=[54, 15], zoom_start=4)

    fill_color = get_color_scale(column)

    folium.Choropleth(
        geo_data=geojson_data,
        name="choropleth",
        data=data_df,
        columns=["ISO", column],
        key_on="feature.properties.ISO_A3_EH",
        fill_color=fill_color,
        fill_opacity=0.7,
        line_opacity=0.2,
        legend_name=title,
    ).add_to(m)

    folium.LayerControl().add_to(m)
    m.save(filename)
    print(f"Saved: {filename}")

# Event categories to map
categories = [
    ('Climatological', 'Climatological Events (1970–2024)', 'Climatological_Events.html'),
    ('Hydrological', 'Hydrological Events (1970–2024)', 'Hydrological_Events.html'),
    ('Meteorological', 'Meteorological Events (1970–2024)', 'Meteorological_Events.html'),
    ('Grand Total', 'Grand Total Events (1970–2024)', 'Grand_Total_Events.html'),
    ('Climatological Events per km2 *1000', 'Climatological Events per 1000 km²', 'Climatological_Events_per_km2.html'),
    ('Hydrological Events per km2 *1000', 'Hydrological Events per 1000 km²', 'Hydrological_Events_per_km2.html'),
    ('Meteorological Events per km2 *1000', 'Meteorological Events per 1000 km²', 'Meteorological_Events_per_km2.html'),
    ('Events per km2 *1000', 'Total Events per 1000 km²', 'Total_Events_per_km2.html'),
]

# Generate all maps
for col, title, filename in categories:
    create_folium_map(geo_json_data, merged, col, title, filename)

