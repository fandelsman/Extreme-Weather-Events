# -*- coding: utf-8 -*-
"""
Created on Fri May 23 11:09:25 2025

@author: FedericoA
"""

import pandas as pd
import matplotlib.pyplot as plt

data = {
    "Region": ["North America"] * 3 + ["Europe"] * 3 + ["East/Southeast Asia"] * 3,
    "EventType": ["Climatological", "Hydrological", "Meteorological"] * 3,
    "FAR": [0.67, 0.37, 0.55, 0.73, 0.41, 0.55, 0.68, 0.4, 0.16],
    "delta_h": [1.26, 0.53, 0.79, 1.59, 0.58, 0.58, 1.88, 0.47, 0.20],
    "delta_N_percent": [3.6, 1.5, 2.1, 5.0, 1.9, 2.0, 6.3, 1.5, 1.3]
}

df = pd.DataFrame(data)

import seaborn as sns

# Define consistent color palette
event_colors = {
    "Climatological": "orange",
    "Hydrological": "blue",
    "Meteorological": "green"
}

# Plot FAR
plt.figure(figsize=(10, 6))
sns.barplot(x="Region", y="FAR", hue="EventType", data=df, palette=event_colors)
plt.title("FAR by Region and Event Type from Carbon Brief")
plt.ylabel("FAR")
plt.show()

# Plot delta_h
plt.figure(figsize=(10, 6))
sns.barplot(x="Region", y="delta_h", hue="EventType", data=df, palette=event_colors)
plt.title("δ by Region and Event Type from Carbon Brief")
plt.ylabel("δ [1/°C]")
plt.show()

# Plot delta_N_percent
plt.figure(figsize=(10, 6))
sns.barplot(x="Region", y="delta_N_percent", hue="EventType", data=df, palette=event_colors)
plt.title("Risk Ratio by Region and Event Type from Carbon Brief")
plt.ylabel("Risk Ratio")
plt.show()
#%%
data2 = {
    "Region": ["North America"] * 3 + ["Europe"] * 3 + ["East/Southeast Asia"] * 3,
    "EventType": ["Climatological", "Hydrological", "Meteorological"] * 3,
    "FAR": [0.86, 0.73, 0.75, 0.93, 0.81, 0.78, 0.82, 0.83, 0.70],
    "delta_h": [1.5, 1, 1.1, 2.0, 1.3, 1.2, 1.3, 1.4, 0.9],
    "delta_N_percent": [7.2, 3.7, 4.0, 13.6, 5.2, 4.6, 5.5, 6.0, 3.4]
}

df2 = pd.DataFrame(data2)

import seaborn as sns

# Define consistent color palette
event_colors = {
    "Climatological": "orange",
    "Hydrological": "blue",
    "Meteorological": "green"
}

# Plot FAR
plt.figure(figsize=(10, 6))
sns.barplot(x="Region", y="FAR", hue="EventType", data=df2, palette=event_colors)
plt.title("FAR by Region and Event Type from EM-DAT")
plt.ylabel("FAR")
plt.show()

# Plot delta_h
plt.figure(figsize=(10, 6))
sns.barplot(x="Region", y="delta_h", hue="EventType", data=df2, palette=event_colors)
plt.title("δ by Region and Event Type from EM-DAT")
plt.ylabel("δ [1/°C]")
plt.show()

# Plot delta_N_percent
plt.figure(figsize=(10, 6))
sns.barplot(x="Region", y="delta_N_percent", hue="EventType", data=df2, palette=event_colors)
plt.title("Risk Ratio by Region and Event Type from EM-DAT")
plt.ylabel("Risk Ratio")
plt.show()
#%%

import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

data1 = {
    "Region": ["North America"] * 3 + ["Europe"] * 3 + ["East/Southeast Asia"] * 3,
    "EventType": ["Climatological", "Hydrological", "Meteorological"] * 3,
    "FAR": [0.67, 0.37, 0.55, 0.73, 0.41, 0.55, 0.68, 0.4, 0.16],
    "delta_h": [1.26, 0.53, 0.79, 1.59, 0.58, 0.58, 1.88, 0.47, 0.20],
    "delta_N_percent": [3.6, 1.5, 2.1, 5.0, 1.9, 2.0, 6.3, 1.5, 1.3]
}

data2 = {
    "Region": ["North America"] * 3 + ["Europe"] * 3 + ["East/Southeast Asia"] * 3,
    "EventType": ["Climatological", "Hydrological", "Meteorological"] * 3,
    "FAR": [0.86, 0.73, 0.75, 0.93, 0.81, 0.78, 0.82, 0.83, 0.70],
    "delta_h": [1.5, 1, 1.1, 2.0, 1.3, 1.2, 1.3, 1.4, 0.9],
    "delta_N_percent": [7.2, 3.7, 4.0, 13.6, 5.2, 4.6, 5.5, 6.0, 3.4]
}

df1 = pd.DataFrame(data1)
df2 = pd.DataFrame(data2)

# Filter to only Europe
#df1 = df1[df1["Region"] == "Europe"]
#df2 = df2[df2["Region"] == "Europe"]


# Shared color palette
event_colors = {
    "Climatological": "orange",
    "Hydrological": "blue",
    "Meteorological": "green"
}

# Variables and titles
variables = [
    ("FAR", "FAR", "FAR", (0, 1)),
    ("delta_h", "δh [1/°C]", "δ", None),
    ("delta_N_percent", "Risk Ratio", "Risk Ratio", None)
]

# Plotting
for var, ylabel, title, ylim in variables:
    fig, axes = plt.subplots(1, 2, figsize=(16, 6), sharey=True)

    # Carbon Brief
    sns.barplot(ax=axes[0], x="Region", y=var, hue="EventType", data=df1, palette=event_colors)
    axes[0].set_title(f"{title} by Region and Event Type\nCarbon Brief")
    axes[0].set_ylabel(ylabel)
    if ylim:
        axes[0].set_ylim(ylim)
    axes[0].legend_.remove()

    # EM-DAT
    sns.barplot(ax=axes[1], x="Region", y=var, hue="EventType", data=df2, palette=event_colors)
    axes[1].set_title(f"{title} by Region and Event Type\nEM-DAT")
    axes[1].set_ylabel("")
    if ylim:
        axes[1].set_ylim(ylim)

    # Legend outside
    handles, labels = axes[1].get_legend_handles_labels()
    axes[1].legend(handles, labels, title="Event Type", bbox_to_anchor=(1.05, 1), loc='upper left')

    plt.tight_layout(rect=[0, 0, 0.9, 1])
    plt.show()

#%%
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np

# Load the dataset
excel_file = r"C:\Users\FedericoA\OneDrive - ORTEC Finance\Thesis\PossibleData\Subselection\FARDeltahStatistics.xlsx"
df = pd.read_excel(excel_file)

# Clean and prepare data
df['Region'] = df['Region'].fillna(method='ffill')
df['Region'] = df['Region'].fillna('North America')  # Replace any remaining NaNs with 'NA'
df['Event Type'] = df['Type and Region']

# Remove unwanted event types
excluded_events = ['Hydrological Negative', 'Hydrological + Meteorological']
df_filtered = df[~df['Event Type'].isin(excluded_events)]

# Select necessary columns
df_clean = df_filtered[['Region', 'Event Type',
                        'FAR mean', 'FAR median', 'FAR 0.05', 'FAR 0.95',
                        'deltah mean', 'deltah median', 'deltah 0.05', 'deltah 0.95',
                        'RR median', 'RR 0.05', 'RR 0.95']]

def plot_heatmap(df, metric, vmin=None, vmax=None, center=None):
    # Define titles and colorbar labels
    if metric == 'FAR mean':
        title = 'FAR'
        cbar_label = 'Mean FAR'
        cbar_ticks = np.linspace(0, 1, 6)  # 0, 0.2, ..., 1.0
    elif metric == 'deltah median':
        title = 'Growth Factor δ'
        cbar_label = 'Median δ [1/°C]'
        cbar_ticks = np.linspace(0, 2, 5)  # 0, 0.5, 1.0, ..., 2.0
    elif metric == 'RR median':
        title = 'Risk Ratio'
        cbar_label = 'Median RR'
        cbar_ticks = np.linspace(1, 6.5, 6)  # 1, 2.1, ..., 6.5
    else:
        title = metric
        cbar_label = metric
        cbar_ticks = None

    # Prepare pivoted data
    heatmap_data = df.pivot_table(
        index='Event Type',
        columns='Region',
        values=metric,
        aggfunc=np.mean
    )

    plt.figure(figsize=(10, 6))
    sns.heatmap(
        heatmap_data,
        annot=True,
        fmt=".2f",
        cmap='Oranges',
        vmin=vmin,
        vmax=vmax,
        center=center,
        linewidths=0.5,
        cbar_kws={'label': cbar_label, 'ticks': cbar_ticks}
    )

    plt.title(f'{title} across Regions and Event Types')
    plt.xlabel('Region')
    plt.ylabel('Event Type')
    plt.tight_layout()
    plt.show()


# Plot heatmaps with appropriate value ranges
plot_heatmap(df_clean, 'FAR mean', vmin=0, vmax=1)         # FAR: range 0 to 1
plot_heatmap(df_clean, 'deltah median', vmin=0, vmax=2)         
plot_heatmap(df_clean, 'RR median', vmin=1, vmax=6.5)                       

#%%
from matplotlib.patches import FancyArrowPatch

# Define consistent color palette
event_colors = {
    "Climatological": "orange",
    "Hydrological": "blue",
    "Meteorological": "green"
}

def plot_dot_error(df, value_col, low_col, high_col, xlabel, title, xlim=None):
    df = df.copy()
    df['ErrorLow'] = df[value_col] - df[low_col]
    df['ErrorHigh'] = df[high_col] - df[value_col]

    plt.figure(figsize=(10, 8))
    regions = df['Region'].unique()
    event_types = df['Event Type'].unique()
    region_positions = {region: i for i, region in enumerate(regions)}
    offset_step = 0.2

    arrow_offset = 0.02  # to avoid plotting right at the edge
    label_offset = 0.10  # vertical offset for label

    ax = plt.gca()

    for i, event in enumerate(event_types):
        subset = df[df['Event Type'] == event]
        event_base = event.split()[0]
        color = event_colors.get(event_base, 'gray')

        for idx, row in subset.iterrows():
            region = row['Region']
            y_val = region_positions[region] + i * offset_step
            x_val = row[value_col]
            err_low = row['ErrorLow']
            err_high = row['ErrorHigh']
            upper_bound = x_val + err_high

            if xlim and upper_bound > xlim[1]:
                # Cap the visible error bar at plot limit
                visible_err_high = xlim[1] - x_val

                plt.errorbar(x=x_val, y=y_val,
                             xerr=[[err_low], [visible_err_high]],
                             fmt='o', capsize=5, color=color)

                # Draw arrow at the edge
                arrow = FancyArrowPatch(
                    (xlim[1] - arrow_offset, y_val), (xlim[1], y_val),
                    arrowstyle='-|>', color=color, mutation_scale=20, lw=1.5
                )
                ax.add_patch(arrow)

                # Add label under the arrow
                label_val = row[high_col]
                # Format label: use exponential notation if > 100
                if label_val > 100:
                    label_text = f"95th percentile = {label_val:.1e}"
                else:
                        label_text = f"95th percentile = {label_val:.0f}"

                plt.text(xlim[1] - 0.1, y_val + label_offset,
                         label_text,
                         ha='right', va='center', fontsize=12, color=color)
            else:
                plt.errorbar(x=x_val, y=y_val,
                             xerr=[[err_low], [err_high]],
                             fmt='o', capsize=5, color=color)

    center_positions = [region_positions[r] + offset_step for r in regions]
    plt.yticks(center_positions, regions, fontsize=12)
    plt.xticks(fontsize= 10)
    plt.xlabel(xlabel, fontsize = 12)
    plt.title(title, fontsize=16)

    if xlim:
        plt.xlim(xlim)

    plt.grid(True, linestyle='--', alpha=0.3)
    plt.tight_layout()
    plt.show()

plot_dot_error(df_clean,
               value_col='FAR mean',
               low_col='FAR 0.05',
               high_col='FAR 0.95',
               xlabel='FAR',
               title='Mean FAR with 90% Confidence Interval Across Regions',
               xlim=(-0.02, 1.02))

plot_dot_error(df_clean,
               value_col='deltah median',
               low_col='deltah 0.05',
               high_col='deltah 0.95',
               xlabel='δ [1/°C]',
               title='Median Growth Factor δ with 90% Confidence Interval Across Regions',
               xlim=(0, 4))

plot_dot_error(df_clean,
               value_col='RR median',
               low_col='RR 0.05',
               high_col='RR 0.95',
               xlabel='RR',
               title='Median Risk Ratio with 90% Confidence Interval Across Regions',
               xlim=(0, 10))
